-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 27, 2019 at 07:42 PM
-- Server version: 10.3.16-MariaDB
-- PHP Version: 7.3.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `jeffsoffroad`
--

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE `customers` (
  `id` int(11) NOT NULL,
  `firstname` varchar(20) NOT NULL,
  `lastname` varchar(20) NOT NULL,
  `sex` tinyint(1) NOT NULL,
  `email` varchar(50) NOT NULL,
  `phone` varchar(50) NOT NULL,
  `address` varchar(50) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`id`, `firstname`, `lastname`, `sex`, `email`, `phone`, `address`, `created_at`, `updated_at`) VALUES
(5, 'Justine Ray', 'Dungan', 1, 'justineray.dungan@yahoo.com', '09954635247', 'Bakakeng Baguio City', '2019-12-27 09:58:48', '2019-12-27 09:58:48'),
(6, 'Arnel', 'Unbreakable', 1, 'arnelunbreakable@yahoo.com', '09999999999', 'Baguio City', '2019-12-27 18:42:08', '2019-12-27 10:40:41');

-- --------------------------------------------------------

--
-- Table structure for table `joborders`
--

CREATE TABLE `joborders` (
  `id` int(11) NOT NULL,
  `cus_id` int(11) NOT NULL,
  `pro_id` int(11) NOT NULL,
  `qty` int(11) NOT NULL,
  `price` float NOT NULL,
  `dis` decimal(10,0) NOT NULL,
  `amount` float NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `joborders`
--

INSERT INTO `joborders` (`id`, `cus_id`, `pro_id`, `qty`, `price`, `dis`, `amount`, `created_at`, `updated_at`) VALUES
(5, 5, 2, 3, 209.75, '25', 471.938, '2019-12-27 17:58:48', NULL),
(6, 5, 3, 5, 169.75, '0', 848.75, '2019-12-27 17:58:48', NULL),
(7, 5, 1, 8, 249.75, '50', 999, '2019-12-27 17:58:48', NULL),
(8, 6, 3, 8, 169.75, '25', 1018.5, '2019-12-27 18:40:41', NULL),
(9, 6, 1, 3, 249.75, '75', 187.312, '2019-12-27 18:40:41', NULL),
(10, 6, 2, 5, 209.75, '50', 524.375, '2019-12-27 18:40:41', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `productname` varchar(50) NOT NULL,
  `qty` int(11) NOT NULL,
  `price` float NOT NULL,
  `dis` decimal(10,0) NOT NULL,
  `amount` tinyint(1) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `productname`, `qty`, `price`, `dis`, `amount`, `created_at`, `updated_at`) VALUES
(1, 'Microtex Chamois', 24, 249.75, '0', 127, '2019-12-05 11:08:54', NULL),
(2, 'Microtex Suede', 24, 209.75, '0', 127, '2019-12-05 11:08:54', NULL),
(3, 'Microtex Ultra', 24, 169.75, '0', 127, '2019-12-05 11:09:51', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `joborders`
--
ALTER TABLE `joborders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `customers`
--
ALTER TABLE `customers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `joborders`
--
ALTER TABLE `joborders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
